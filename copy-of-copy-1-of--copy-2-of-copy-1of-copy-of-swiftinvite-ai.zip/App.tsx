
import React, { useState } from 'react';
import { AppView, EventType, InvitationData } from './types';
import HomeView from './components/HomeView';
import GeneratorView from './components/GeneratorView';
import EditorView from './components/EditorView';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.HOME);
  const [selectedEvent, setSelectedEvent] = useState<EventType | null>(null);
  const [invitationData, setInvitationData] = useState<InvitationData | null>(null);

  const handleSelectEvent = (event: EventType) => {
    setSelectedEvent(event);
    setView(AppView.GENERATOR);
  };

  const handleGenerated = (data: InvitationData) => {
    setInvitationData(data);
    setView(AppView.EDITOR);
  };

  const handleBack = () => {
    if (view === AppView.GENERATOR) setView(AppView.HOME);
    if (view === AppView.EDITOR) setView(AppView.GENERATOR);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white border-b px-6 py-4 flex items-center justify-between sticky top-0 z-50">
        <h1 
          className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent cursor-pointer"
          onClick={() => setView(AppView.HOME)}
        >
          SwiftInvite AI
        </h1>
        {view !== AppView.HOME && (
          <button 
            onClick={handleBack}
            className="text-gray-600 hover:text-indigo-600 font-medium transition-colors flex items-center gap-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back
          </button>
        )}
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        {view === AppView.HOME && (
          <HomeView onSelect={handleSelectEvent} />
        )}
        {view === AppView.GENERATOR && selectedEvent && (
          <GeneratorView 
            eventType={selectedEvent} 
            onGenerated={handleGenerated} 
          />
        )}
        {view === AppView.EDITOR && invitationData && (
          <EditorView 
            data={invitationData} 
          />
        )}
      </main>
    </div>
  );
};

export default App;
