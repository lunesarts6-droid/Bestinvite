import React, { useEffect, useRef, useState } from 'react';
import { InvitationData, TextLayer } from '../types';

// Declare fabric globally as we'll use it from a CDN for simplicity and reliability in this environment
declare const fabric: any;

interface EditorViewProps {
  data: InvitationData;
}

const FONT_FAMILIES = [
  { name: 'Modern (Inter)', value: 'Inter, sans-serif' },
  { name: 'Elegant (Playfair Display)', value: '"Playfair Display", serif' },
  { name: 'Clean (Montserrat)', value: 'Montserrat, sans-serif' },
  { name: 'Script (Dancing Script)', value: '"Dancing Script", cursive' },
  { name: 'Classic (Roboto Mono)', value: '"Roboto Mono", monospace' },
];

const EditorView: React.FC<EditorViewProps> = ({ data }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fabricCanvas = useRef<any>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [selectedObject, setSelectedObject] = useState<any>(null);
  // Dummy state to force React re-render when Fabric objects are mutated internally
  const [, setTick] = useState(0);

  const forceUpdate = () => setTick(t => t + 1);

  useEffect(() => {
    // Load Fabric.js from CDN
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.1/fabric.min.js';
    script.onload = () => initCanvas();
    document.body.appendChild(script);

    return () => {
      if (fabricCanvas.current) {
        fabricCanvas.current.dispose();
      }
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getCanvasDimensions = () => {
    const maxWidth = Math.min(window.innerWidth - 48, 500);
    const maxHeight = window.innerHeight * 0.65;
    
    let ratio = 1; // height / width
    switch(data.aspectRatio) {
      case '1:1': ratio = 1; break;
      case '5:7': ratio = 7/5; break;
      case '2:3': ratio = 3/2; break;
      case '4:3': ratio = 3/4; break;
      default: ratio = 7/5;
    }

    let width = maxWidth;
    let height = width * ratio;

    if (height > maxHeight) {
      height = maxHeight;
      width = height / ratio;
    }

    return { width, height };
  };

  const initCanvas = () => {
    if (!canvasRef.current) return;

    const { width, height } = getCanvasDimensions();

    fabricCanvas.current = new fabric.Canvas(canvasRef.current, {
      width,
      height,
      backgroundColor: '#ffffff',
    });

    // Listen for selection events to update UI
    fabricCanvas.current.on('selection:created', (e: any) => setSelectedObject(e.selected[0]));
    fabricCanvas.current.on('selection:updated', (e: any) => setSelectedObject(e.selected[0]));
    fabricCanvas.current.on('selection:cleared', () => setSelectedObject(null));
    
    // Also listen for object modification (dragging, scaling) to refresh UI if needed
    fabricCanvas.current.on('object:modified', () => forceUpdate());

    fabric.Image.fromURL(data.backgroundImage, (img: any) => {
      const scaleX = width / img.width;
      const scaleY = height / img.height;
      const scale = Math.max(scaleX, scaleY);
      
      img.set({
        originX: 'center',
        originY: 'center',
        scaleX: scale,
        scaleY: scale,
        selectable: false,
        evented: false,
        left: width / 2,
        top: height / 2,
      });
      
      fabricCanvas.current.setBackgroundImage(img, fabricCanvas.current.renderAll.bind(fabricCanvas.current));
      
      const textColor = data.textLayers[0]?.color || '#333333';

      // Add Text Layers
      data.textLayers.forEach((layer) => {
        const text = new fabric.IText(layer.text, {
          left: (layer.left / 100) * width,
          top: (layer.top / 100) * height,
          fontSize: (layer.fontSize / 500) * width,
          fontFamily: layer.role === 'date_daynum' || layer.role === 'main' ? '"Playfair Display", serif' : 'Inter, sans-serif',
          fontWeight: layer.fontWeight || 'normal',
          fill: layer.color || textColor,
          originX: 'center',
          originY: 'center',
          textAlign: 'center',
          cornerStyle: 'circle',
          cornerColor: '#4f46e5',
          cornerSize: 8,
          transparentCorners: false,
          borderColor: '#4f46e5',
        });
        fabricCanvas.current.add(text);
      });

      // Add Horizontal Divider Lines
      const horizontalLineY1 = (22 / 100) * height;
      const horizontalLineY2 = (84 / 100) * height;
      const lineWidth = (30 / 100) * width;

      const createHorizontalLine = (y: number) => new fabric.Line([width / 2 - lineWidth / 2, y, width / 2 + lineWidth / 2, y], {
        stroke: textColor,
        strokeWidth: 2,
        selectable: true,
        opacity: 0.7,
        originX: 'center',
        originY: 'center',
        cornerStyle: 'circle',
        cornerColor: '#4f46e5',
        cornerSize: 10,
        transparentCorners: false,
        padding: 15, // Greatly improves click/touch area for easier moving
        hoverCursor: 'move',
        borderColor: '#4f46e5',
      });

      fabricCanvas.current.add(createHorizontalLine(horizontalLineY1));
      fabricCanvas.current.add(createHorizontalLine(horizontalLineY2));

      // Add Vertical Dividers for the Date Block
      const dateY = (60 / 100) * height;
      const leftLineX = (42 / 100) * width;
      const rightLineX = (58 / 100) * width;
      const lineLength = (5 / 100) * height;

      const createVerticalLine = (x: number) => new fabric.Line([x, dateY - lineLength, x, dateY + lineLength], {
        stroke: textColor,
        strokeWidth: 1.5,
        selectable: true,
        opacity: 0.6,
        cornerStyle: 'circle',
        cornerColor: '#4f46e5',
        cornerSize: 8,
        transparentCorners: false,
        padding: 15, // Greatly improves click/touch area for easier moving
        hoverCursor: 'move',
        borderColor: '#4f46e5',
      });

      fabricCanvas.current.add(createVerticalLine(leftLineX));
      fabricCanvas.current.add(createVerticalLine(rightLineX));

      fabricCanvas.current.renderAll();
      setIsLoaded(true);
    });
  };

  const handleDownload = () => {
    if (!fabricCanvas.current) return;
    fabricCanvas.current.discardActiveObject().renderAll();
    const dataURL = fabricCanvas.current.toDataURL({
      format: 'png',
      quality: 1.0,
      multiplier: 2,
    });
    const link = document.createElement('a');
    link.download = `Invitation-${data.eventType}.png`;
    link.href = dataURL;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const updateSelectedStyle = (property: string, value: any) => {
    if (!fabricCanvas.current) return;
    const activeObject = fabricCanvas.current.getActiveObject();
    if (!activeObject) return;
    
    activeObject.set(property, value);
    fabricCanvas.current.requestRenderAll();
    forceUpdate();
  };

  const toggleBold = () => {
    if (!selectedObject || selectedObject.type !== 'i-text') return;
    const isBold = selectedObject.fontWeight === 'bold';
    updateSelectedStyle('fontWeight', isBold ? 'normal' : 'bold');
  };

  const toggleItalic = () => {
    if (!selectedObject || selectedObject.type !== 'i-text') return;
    const isItalic = selectedObject.fontStyle === 'italic';
    updateSelectedStyle('fontStyle', isItalic ? 'normal' : 'italic');
  };

  const handleSizeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value, 10);
    if (selectedObject?.type === 'i-text') {
      updateSelectedStyle('fontSize', val);
    } else if (selectedObject?.type === 'line') {
      updateSelectedStyle('strokeWidth', val / 10); // Subtle stroke width control
    }
  };

  return (
    <div className="flex flex-col items-center animate-in fade-in zoom-in-95 duration-500">
      <div className="w-full max-w-lg mb-6 flex flex-col gap-4 px-4">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-xl font-bold text-gray-800">Customize Your Invitation</h3>
            <p className="text-sm text-gray-500 italic">Double-click text to edit, drag lines/text to move</p>
          </div>
          <button
            onClick={handleDownload}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-6 rounded-lg shadow-md transition-all flex items-center gap-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Download
          </button>
        </div>

        {/* Formatting Toolbar */}
        <div className={`flex flex-col gap-3 p-4 bg-white border border-gray-200 rounded-2xl shadow-sm transition-all duration-300 ${selectedObject ? 'opacity-100 ring-2 ring-indigo-500 ring-opacity-20' : 'opacity-40 pointer-events-none'}`}>
          <div className="flex items-center gap-2">
            <select 
              className={`flex-1 bg-gray-50 border border-gray-200 rounded-lg px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 ${selectedObject?.type !== 'i-text' ? 'opacity-50 cursor-not-allowed' : ''}`}
              value={selectedObject?.fontFamily || ''}
              onChange={(e) => updateSelectedStyle('fontFamily', e.target.value)}
              disabled={selectedObject?.type !== 'i-text'}
            >
              <option value="" disabled>Select Font</option>
              {FONT_FAMILIES.map(font => (
                <option key={font.value} value={font.value}>{font.name}</option>
              ))}
            </select>
            
            <button 
              onClick={toggleBold}
              className={`p-1.5 rounded-lg border transition-all ${selectedObject?.fontWeight === 'bold' ? 'bg-indigo-100 border-indigo-300 text-indigo-700' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'} ${selectedObject?.type !== 'i-text' ? 'opacity-50 cursor-not-allowed' : ''}`}
              title="Bold"
              disabled={selectedObject?.type !== 'i-text'}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"></path>
                <path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"></path>
              </svg>
            </button>

            <button 
              onClick={toggleItalic}
              className={`p-1.5 rounded-lg border transition-all ${selectedObject?.fontStyle === 'italic' ? 'bg-indigo-100 border-indigo-300 text-indigo-700' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'} ${selectedObject?.type !== 'i-text' ? 'opacity-50 cursor-not-allowed' : ''}`}
              title="Italic"
              disabled={selectedObject?.type !== 'i-text'}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="19" y1="4" x2="10" y2="4"></line>
                <line x1="14" y1="20" x2="5" y2="20"></line>
                <line x1="15" y1="4" x2="9" y2="20"></line>
              </svg>
            </button>

            <div className="h-8 w-px bg-gray-200 mx-1"></div>

            <div className="flex items-center gap-1">
              <input 
                type="color" 
                value={selectedObject?.fill || selectedObject?.stroke || '#333333'} 
                onChange={(e) => updateSelectedStyle(selectedObject?.type === 'line' ? 'stroke' : 'fill', e.target.value)}
                className="w-8 h-8 p-0.5 bg-white border border-gray-200 rounded-lg cursor-pointer hover:border-indigo-300 transition-colors"
                title="Color"
              />
            </div>
          </div>

          <div className="flex items-center gap-4 px-1">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest min-w-[60px]">
              {selectedObject?.type === 'line' ? 'Thickness' : 'Size'}
            </span>
            <input 
              type="range" 
              min={selectedObject?.type === 'line' ? "1" : "10"} 
              max={selectedObject?.type === 'line' ? "100" : "150"} 
              value={selectedObject?.type === 'line' ? (selectedObject?.strokeWidth * 10) : (selectedObject?.fontSize || 20)}
              onChange={handleSizeChange}
              className="flex-1 h-2 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
            <span className="text-xs font-mono text-gray-500 w-8 text-right">
              {Math.round(selectedObject?.type === 'line' ? selectedObject?.strokeWidth : selectedObject?.fontSize) || 0}
            </span>
          </div>
        </div>
      </div>

      <div className="canvas-wrapper relative bg-white p-2 rounded-xl shadow-2xl overflow-hidden border border-gray-100">
        {!isLoaded && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-50 bg-opacity-80 z-10 rounded-xl">
             <div className="animate-pulse text-indigo-600 font-medium">Initializing Editor...</div>
          </div>
        )}
        <canvas ref={canvasRef} id="invitation-canvas" />
      </div>

      <div className="mt-8 text-center text-gray-400 text-xs">
        Powered by SwiftInvite AI • Gemini Vision & Flash
      </div>
    </div>
  );
};

export default EditorView;