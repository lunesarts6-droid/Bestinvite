
import React, { useState } from 'react';
import { EventType, InvitationData, AspectRatio } from '../types';
import { generateInvitationBackground, generateInvitationTextLayers } from '../services/geminiService';

interface GeneratorViewProps {
  eventType: EventType;
  onGenerated: (data: InvitationData) => void;
}

const COLOR_THEMES = [
  'Midnight Blue with Gold accents',
  'Deep Emerald Green with Copper foil',
  'Soft Lavender and Silver',
  'Terracotta and Warm Cream',
  'Deep Charcoal with Pearl white',
  'Sage Green and Crisp White',
  'Dusty Rose and Champagne Gold',
  'Royal Purple and Antique Gold',
  'Classic Black and Platinum',
  'Ethereal Light Blue and White',
  'Navy Blue with Bronze',
  'Rich Forest Green with Cream',
  'Moody Burgundy and Gold',
  'Pastel Peach and Mint',
  'Modern Slate and Teal'
];

const RATIOS: { label: string; value: AspectRatio; icon: string }[] = [
  { label: 'Classic', value: '5:7', icon: 'M6 2h12v20H6z' },
  { label: 'Square', value: '1:1', icon: 'M4 4h16v16H4z' },
  { label: 'Slim', value: '2:3', icon: 'M7 2h10v20H7z' },
  { label: 'Wide', value: '4:3', icon: 'M2 6h20v12H2z' },
];

const GeneratorView: React.FC<GeneratorViewProps> = ({ eventType, onGenerated }) => {
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState('');
  const [selectedRatio, setSelectedRatio] = useState<AspectRatio>('5:7');

  const handleGenerate = async () => {
    setLoading(true);
    const randomTheme = COLOR_THEMES[Math.floor(Math.random() * COLOR_THEMES.length)];
    
    try {
      setStep(`Applying ${randomTheme} theme...`);
      const backgroundImage = await generateInvitationBackground(eventType, randomTheme, selectedRatio);
      
      setStep('Writing the details...');
      const textLayers = await generateInvitationTextLayers(eventType, randomTheme);
      
      onGenerated({
        eventType,
        backgroundImage,
        textLayers,
        aspectRatio: selectedRatio
      });
    } catch (error) {
      console.error(error);
      alert('Something went wrong during generation. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto text-center">
      <div className="mb-8">
        <span className="inline-block px-4 py-1 rounded-full bg-indigo-100 text-indigo-700 text-sm font-bold uppercase tracking-wider mb-2">
          {eventType}
        </span>
        <h2 className="text-3xl font-bold text-gray-900">Choose Your Format</h2>
      </div>

      {!loading ? (
        <div className="bg-white p-8 md:p-12 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 w-full mb-10">
            {RATIOS.map((ratio) => (
              <button
                key={ratio.value}
                onClick={() => setSelectedRatio(ratio.value)}
                className={`flex flex-col items-center p-4 rounded-2xl border-2 transition-all ${
                  selectedRatio === ratio.value
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                    : 'border-gray-100 bg-gray-50 text-gray-400 hover:border-gray-300'
                }`}
              >
                <svg
                  className="w-10 h-10 mb-2"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d={ratio.icon} />
                </svg>
                <span className="text-xs font-bold uppercase tracking-tighter">{ratio.label}</span>
                <span className="text-[10px] opacity-60">{ratio.value}</span>
              </button>
            ))}
          </div>

          <p className="text-gray-500 mb-8 max-w-sm text-sm">
            Our AI will create a unique, high-quality invitation in <b>{RATIOS.find(r => r.value === selectedRatio)?.label}</b> format with a fresh color palette.
          </p>
          
          <button
            onClick={handleGenerate}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg hover:shadow-indigo-200 transition-all text-lg"
          >
            Generate Invitation
          </button>
        </div>
      ) : (
        <div className="bg-white p-12 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center">
          <div className="relative w-20 h-20 mb-6">
            <div className="absolute inset-0 border-4 border-indigo-100 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"></div>
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">{step}</h3>
          <p className="text-gray-500">Each design is unique and custom-colored...</p>
        </div>
      )}
    </div>
  );
};

export default GeneratorView;
