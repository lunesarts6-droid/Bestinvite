
import { GoogleGenAI, Type } from "@google/genai";
import { EventType, TextLayer, AspectRatio } from "../types";

export const generateInvitationBackground = async (eventType: EventType, colorTheme: string, aspectRatio: AspectRatio): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const eventElements: Record<EventType, string> = {
    'Wedding': 'a miniature elegant bride and groom couple standing at the absolute bottom-most edge, with delicate floral borders clustering tightly to the extreme outer corners',
    'Engagement': 'two sparkling champagne glasses and delicate rings tucked into the very extreme corner edge with no margin',
    'Birthday': 'a luxury gift box and soft aesthetic balloons resting precisely at the extreme corners',
    'Graduation': 'a realistic 3D graduation cap and diploma resting on the absolute bottom-most horizontal limit',
    'Baby Shower': 'soft ribbons and delicate clouds framing only the very outermost limits of the invitation'
  };

  // Map user requested ratios to Gemini supported ratios ('1:1', '3:4', '4:3', '9:16', '16:9')
  let apiRatio: '1:1' | '3:4' | '4:3' | '9:16' | '16:9' = '3:4';
  if (aspectRatio === '1:1') apiRatio = '1:1';
  else if (aspectRatio === '4:3') apiRatio = '4:3';
  else if (aspectRatio === '5:7' || aspectRatio === '2:3') apiRatio = '3:4';

  const prompt = `A high-end, professional 3D render of a ${eventType} invitation card.
  THEME: The card must be made of premium textured ${colorTheme} paper. 
  The card MUST have a visible, elegant paper grain texture in the specified ${colorTheme} colors.
  The composition MUST feature an ABSOLUTELY MASSIVE, VAST, and pristine blank central area that occupies at least 90% of the surface. 
  This central writing space must be a wide, clean, uninterrupted void in a matching ${colorTheme} shade.
  ALL decorative elements MUST be pushed to the extreme, absolute edges and corners with zero margin:
  1. ${eventElements[eventType]}.
  2. The decorations should appear as physical objects framing the absolute outer limits of the card.
  3. Use soft studio lighting with realistic, subtle shadows.
  ABSOLUTELY NO TEXT, letters, numbers, or characters should be generated in the image.`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [{ text: prompt }]
    },
    config: {
      imageConfig: {
        aspectRatio: apiRatio
      }
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }

  throw new Error("Failed to generate image background");
};

export const generateInvitationTextLayers = async (eventType: EventType, colorTheme: string): Promise<TextLayer[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

  const prompt = `Create content for a ${eventType} invitation on a ${colorTheme} background. 
  You must provide exactly 10 text layers to form a specific layout.
  Text color MUST contrast perfectly with ${colorTheme}.

  LAYER SPECIFICATIONS:
  1. role: "intro". Text: "You are invited to". (fontSize: 18). top: 15, left: 50.
  2. role: "main". Text: The event subject (e.g., "Sarah's 30th"). (fontSize: 55). top: 30, left: 50. bold.
  3. role: "desc". Text: Catchy line. (fontSize: 22). top: 44, left: 50.
  
  --- DATE BLOCK (Visual Center around top 60%) ---
  4. role: "date_dayname". Text: Day of week (e.g. "SATURDAY"). (fontSize: 18). top: 60, left: 35. uppercase.
  5. role: "date_month". Text: Month (e.g. "AUGUST"). (fontSize: 14). top: 56, left: 50. uppercase.
  6. role: "date_daynum". Text: Day number (e.g. "24"). (fontSize: 48). top: 60, left: 50. BOLD.
  7. role: "date_year". Text: Year (e.g. "2024"). (fontSize: 14). top: 65, left: 50.
  8. role: "date_time". Text: Time (e.g. "AT 07 PM"). (fontSize: 18). top: 60, left: 65. uppercase.
  
  --- FOOTER ---
  9. role: "location". Text: The venue/address. (fontSize: 22). top: 78, left: 50.
  10. role: "rsvp". Text: RSVP details. (fontSize: 18). top: 90, left: 50.

  Note: left 50 is center. Left 35 and 65 create the three-part horizontal layout for the date.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            text: { type: Type.STRING },
            fontSize: { type: Type.NUMBER },
            top: { type: Type.NUMBER },
            left: { type: Type.NUMBER },
            fontWeight: { type: Type.STRING },
            color: { type: Type.STRING },
            role: { type: Type.STRING }
          },
          required: ["text", "fontSize", "top", "left", "color", "role"]
        }
      }
    }
  });

  try {
    const rawJson = response.text.trim();
    const data = JSON.parse(rawJson);
    return data.map((item: any, index: number) => ({
      ...item,
      id: `text-${index}`,
      fontWeight: item.fontWeight || (item.role === 'main' || item.role === 'date_daynum' ? 'bold' : 'normal')
    }));
  } catch (e) {
    console.error("Failed to parse AI text layers, using defaults", e);
    return getDefaultLayers(eventType);
  }
};

const getDefaultLayers = (eventType: EventType): TextLayer[] => [
  { id: '1', role: 'intro', text: "You are cordially invited to", fontSize: 18, top: 15, left: 50, color: '#374151' },
  { id: '2', role: 'main', text: `${eventType} Celebration`, fontSize: 55, top: 30, left: 50, fontWeight: 'bold', color: '#111827' },
  { id: '3', role: 'desc', text: 'An evening of joy and laughter', fontSize: 22, top: 44, left: 50, color: '#374151' },
  { id: '4', role: 'date_dayname', text: 'SATURDAY', fontSize: 18, top: 60, left: 35, color: '#374151' },
  { id: '5', role: 'date_month', text: 'AUGUST', fontSize: 14, top: 56, left: 50, color: '#374151' },
  { id: '6', role: 'date_daynum', text: '24', fontSize: 48, top: 60, left: 50, fontWeight: 'bold', color: '#111827' },
  { id: '7', role: 'date_year', text: '2024', fontSize: 14, top: 65, left: 50, color: '#374151' },
  { id: '8', role: 'date_time', text: 'AT 07 PM', fontSize: 18, top: 60, left: 65, color: '#374151' },
  { id: '9', role: 'location', text: 'The Grand Conservatory Gardens', fontSize: 22, top: 78, left: 50, color: '#374151' },
  { id: '10', role: 'rsvp', text: 'RSVP by August 1st to 555-0123', fontSize: 18, top: 90, left: 50, color: '#374151' },
];
